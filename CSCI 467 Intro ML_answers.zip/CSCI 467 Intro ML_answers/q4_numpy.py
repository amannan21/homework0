"""Code for HW0 Problem 4: numpy & gradient descent."""
import argparse
import sys

import numpy as np

def f(x, u, v):
    """Compute f(x) using the given values of u and v."""
    ### BEGIN_SOLUTION 4a

    # u_to_be_transpose = u.reshape(-1, 1) # the -1 automatically reshapes based on column 
    result = -np.dot(u, x) + np.linalg.norm(x - v)**2 #linalg -> euciledan distance 
    return result
    

    raise NotImplementedError
    ### END_SOLUTION 4a


def grad_f(x, u, v):
    """Compute gradient of f(x) using the given values of u and v."""
    ### BEGIN_SOLUTION 4c
    # for each index of values in u and v, find the 
    # ∇f(x) = -u + 2(x - v)

    #2x + u -2v

    val1 = 2*x
    val2 = -u
    result = val1 + val2
    val3 = 2*v
    result = result - val3

    return result


    # does there need to be a difference between two and three dimensions? 
    raise NotImplementedError
    ### END_SOLUTION 4c


def find_optimum(u, v, learning_rate=1e-1, num_iters=100):
    """Find the x that minimizes f(x) given values of u and v."""
    dim = u.shape[0]  # Dimension of u
    ### BEGIN_SOLUTION 4d
    x = np.zeros(dim)


    for i in range(num_iters):
        x = x - learning_rate * grad_f(x, u, v)
    
    return x

    raise NotImplementedError
    ### END_SOLUTION 4d

def run_gradient_descent(u, v):
    print(f'\nRunning gradient descent with u={u}, v={v}')
    x = find_optimum(u, v)
    print('Optimal x: ', x)
    print('Optimal f(x): ', f(x, u, v))

def main():
    # 2-dimensional test-case
    run_gradient_descent(np.array([1, 5]), np.array([1, 0]))

    # 3-dimensional test-case
    run_gradient_descent(np.array([-1, 3, 2]), np.array([2, -3, 1]))


if __name__ == '__main__':
    main()

